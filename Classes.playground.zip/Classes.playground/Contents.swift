import UIKit




//class TuwaiqLabel{
//    var value: String = ""
//    let hight: Double = 0.0
//    let width: Double = 0.0
//    let textColor: String = ""
//    let backgroundColor: String = ""
//    let font: String = ""
//
//    func resetLabel (){
//        value = ""
//    }
//}
//
//var age = TuwaiqLabel()
//age.value = "22"
//print("Your age is:" , age.value)
//age.resetLabel()
//print("Your age is:" , age.value)
//
//
//let x = UIImageView()














//class Pesron {
//    var name: String = ""
//    var age: Int = 17
//    var tall: Double = 0.0
//
//    func sayHello() {
//        // play sound and Say Hello
//        print("Hello friend 😍")
//    }
//}
//
//var person = Pesron()
//person.age = 18
//person.sayHello()
//print("person age \(person.age)")
